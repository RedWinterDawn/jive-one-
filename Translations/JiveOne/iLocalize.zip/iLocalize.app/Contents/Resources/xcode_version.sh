
buildnumber=`git rev-list HEAD --count`
agvtool new-version -all $(($buildnumber+4300))


